import { Settings } from "../components/Settings";

const SettingsPage = () => {
  return <Settings />;
};

export default SettingsPage;
