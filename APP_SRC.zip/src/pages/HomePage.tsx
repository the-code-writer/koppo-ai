import { HomeScreen2 } from "../components/HomeScreen2";

const HomePage = () => {
  return <HomeScreen2 />;
};

export default HomePage;
