import { ConfigEndpoint } from "../components/ConfigEndpoint";

const ConfigEndpointPage = () => {
  return <ConfigEndpoint />;
};

export default ConfigEndpointPage;
