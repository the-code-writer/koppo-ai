import { Bots } from "../components/Bots";

const BotsPage = () => {
  return <Bots />;
};

export default BotsPage;
